
// var str1  = "+@90#2$%29794\t78;7/738,7;5:9\r\n50\n3\n\r786abcd|1111,07738759503,";
var str1 = "091123456178";
console.log("Actual string:", str1);

var replaceExceptNumbers  = str1.replace(/[^0-9|,|:|;|\r\n|\t|\n|/|\|]/g, '');
console.log("Output string:",replaceExceptNumbers);


//splitting the number obtained
    var final_string1 = replaceExceptNumbers.split(/[,:;\r\n\t\n|]+/);
    console.log("final_string",final_string1);
    
//Variablizing
    

//Starting the traversal

    for ( var i= 0; i < final_string1.length; i++ ) {
        
        //Checking for 10 or less than 10 characters

        if ( final_string1[i].length < 10 ) {

            console.log("Invalid Count :", final_string1[i]);

        } else if ( final_string1[i].length == 10 ) {

            //Storing the character at first index in firstChar

            var firstChar = final_string1[i].charAt(0);

            //Variablizing for slash

            var slash = new RegExp("/");

            //Checks if slash comes in between the 10 characters

            var res = slash.test(final_string1[i]);

            if ( parseInt(firstChar) === 0 || res === true ) {
  
                console.log("Its a Invalid Number in 1oth :::", final_string1[i]);
            } 
            
            else{
                console.log("Its a Valid Number in 10th:::", final_string1[i]);
            }  
        
        } else if ( final_string1[i].length == 11 ) {

            // Check whether zero is at first position 

            var firstChar = final_string1[i].charAt(0);

            if( parseInt(firstChar) === 0 ){        //If found it will remove that zero
                
                var newString = final_string1[i].slice(1);
                console.log("Its a Valid Number in 11th :::",newString);
            }   
            
            else{
                console.log("Its a Invalid Number in 11th :::",newString);
            }

        } else if ( final_string1[i].length >= 12 ) {
            console.log("Hi ssss");
            // Check whether zero is at first position 

            var firstChar = final_string1[i].charAt(0);

            if( parseInt(firstChar) === 0 ){        //If found it will remove that zero
                
                var newString = final_string1[i].slice(1);
                //console.log(newString);
                if(newstring != 0 ){
                    console.log(newString);
                    var slash = new RegExp("/");

                //Checks if slash comes in between the characters
    
                var res = slash.test(newString);

                if( res === true ){

                    var x = final_string1[i].indexOf("/");
                    
                    var newstring = final_string1[i].substring(0,x);
                    console.log("hi Zero In !2",newstring);  
                }


                }
            
            }else {
                var slash = new RegExp("/");

                //Checks if slash comes in between the characters
    
                var res = slash.test(newString);

                if( res === true ){

                    var x = final_string1[i].indexOf("/");
                    
                    var newstring = final_string1[i].substring(0,x);
                    console.log("Not Zero In !2",newstring);
                    
                }

            }

            
                var slash = new RegExp("/");

                //Checks if slash comes in between the characters
    
                var res = slash.test(newString);

                if( res === true ){

                    var x = final_string1[i].indexOf("/");
                    
                    var newstring = final_string1[i].substring(0,x);
                    
                }

        }
    }       



           /* } else {                                // Else 
                var slash = new RegExp("/");

                //Checks if slash comes in between the characters
    
                var res = slash.test(final_string1[i]);

                if( res === true ){

                   

                }
            }
        }



    }*/










         //   if(res === true) {

        //     var x = final_string1[i].indexOf("/");
        //     console.log(x);

        //     var newstring = final_string1[i].substring(0,x);
            
        //     if(newstring.length !=10)
        //     {

        //         console.log("doesn't has 10 digits:",newstring);
        //     } else {

        //         console.log("Valid Number:", newstring);
        //     }
        //   }
        // } else if ( final_string1[i].length >= 12 ) {

        //     var find91  =   final_string1[i].slice(0,2);

        //     console.log("in 12th digit ::: " + find91)
        //     console.log("10 digit number ::: " + final_string1[i].slice(2));
        //     var secondChar = final_string1[i];

        //     if ( find91 === "91" ) {

        //         var secondChar = final_string1[i].slice(2);
        //         console.log("hi",secondChar);
        //         console.log("hi",final_string1[i]);

        //         var slash = new RegExp("/");
        //         var res = slash.test(final_string1[i]);

        //         if (res === true)
        //         {
        //             var x = final_string1[i].indexOf("/");
        //             console.log(x);
            
        //             var newstring = final_string1[i].substring(0,x);

        //             if(newstring.length !=10)
        //             {
        //                 console.log("doesn't has 10 digits:",newstring);
        //             }
        //         } else {
                    
        //             console.log("Valid Number:", newstring);
        //         }
        //     } else {

        //         console.log("Invalid Number ::: " + final_string1[i]);
        //     }
        // }