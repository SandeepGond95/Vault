const express = require('express');
const exphbs = require('express-handlebars');
const redis = require('redis');
const path = require('path');
const bodyParser = require('body-parser');
const methodOverride = require('method-override');
const port = 3000;
const app = express();

//create redis client
let client = redis.createClient();
client.on('connect', function() {
    console.log("connected to redis");
});



//view engine
app.engine('handlebars' ,exphbs ({defaultLayout :'main'}));
app.set('view engine','handlebars');

//body-parser
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended :true}));

//methodOverride
app.use(methodOverride('method'));

//get users
app.get('/', function(req,res){
    let user = req.body.user;

    client.hgetall(user, function (err,val){
        if(val){
            res.send(val);
        }
        else{
            res.send(err);
        }
    });    
});

//Insert a user or create a new user
app.post('/', (req, res) => {
    let User = req.body.user;
    let Name = req.body.name;
    client.hmset(User,[
    'name', Name
    ] ,function (err,val){
        if(val){
            console.log("value pushed successfully");
            res.send(val);
        }
        else{
            res.send(err);
        }
    });    
});


//updating an entry
app.put('/', (req,res) =>{
    let User = req.body.user;
    let phone = req.body.phoneNo;
    client.hmset(User,[
        'phoneNo', phone
        ] ,function (err,val){
            if(val){
                console.log("value updated successfully");
                res.send(val);
            }
            else{
                res.send(err);
            }
        });    
});


//Delete an employees
app.delete('/', (req, res) => {
    let User = req.body.user;
client.hdel(User, function (err,val) {
    if(val){
        console.log("values deleted successfully");
        res.send(val);
    }
    else{
        res.send(err);
    }
    
});
});


app.listen(port, () =>{
    console.log('server started on port' +port);
});

