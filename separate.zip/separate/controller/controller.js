const express = require('express');
const request = require('request');
const mongoose = require('mongoose');
const leadModel = require("../model/model");


/*Just to check what is returned when existing lead is updated
exports.Receivelead = (req,res) =>{
    //console.log("got it" +req);
    console.log("got it" +req.body);
    console.log("got it" +req.body.lead_id);
}*/


exports.Receivelead = (req,res) =>{
    console.log("Got the body from request");
    console.log(req.body);

    const lead_obj = new leadModel({
        lead_id : req.body.lead_id,
        lead_first_name : req.body.lead_first_name,
        lead_stage_id : req.body.lead_stage_id,
        lead_last_name : req.body.lead_last_name,
        lead_email : req.body.lead_email,
        lead_work_number : req.body.lead_work_number,
        lead_mobile_number : req.body.lead_mobile_number,
        lead_company_name : req.body.lead_company_name
    });


    lead_obj.save().then((error,value)=>{
        if(value){
        
            console.log("Value for new Lead pushed in database successfully");
            res.send("done");
                }
        else {
            console.log(error);
            res.send(error);
            }
                     });


   //logic to check whether the fetched entry is duplicated in the db or not
//    leadModel.findOneAndUpdate({"lead_id":req.body.lead_id}, {$set:{ "lead_first_name" : req.body.lead_first_name,
//                                                                     "lead_last_name" : req.body.lead_last_name,
//                                                                     "lead_email": req.body.lead_email,
//                                                                     "lead_work_number": req.body.lead_work_number,
//                                                                     "lead_mobile_number": req.body.lead_mobile_number,
//                                                                     "lead_company_name": req.body.lead_company_name}}).then(val => {
//     //console.log(val);
//     if(val){
//         console.log("detail updated");
        
//     }

//     else{
//         console.log("new entry");
//         lead_obj.save().then((error,value)=>{
//             if(value){
            
//                 console.log("Value for new Lead pushed in database successfully");
//                // res.send("done");
//                     }
//             else {
//                 console.log(error);
//                 //res.send(err);
//                 }
//                                     });
//         }

//    });
}

    /*

    //For pushing the details in dialer(from var requestData---request call)
    var requestData = {
      "json":{
          "customerNumber" : req.body.lead_mobile_number || "",
          "customerName": req.body.lead_first_name || "",
          "customerEmail":req.body.lead_email || "",
          "processId": "5",
          "processName":"",
          "processType": "Auto",
          "campaignId" : "1",
          "campaignName": "Test",
          "leadsetId": "5",
          "leadsetName": "iidetest",
          "leadScore" : 1000 
      },
     "tokenId":"c3fcef81d81f05885b143a1528e8ba17"
  }
  const options = {
  url: 'https://iide.slashrtc.com/slashRtc/webApis/setLeadDetailInProcess',
  method: "POST",
  rejectUnauthorized: false,
  headers: {
      'content-type': 'application/json',
      'Accept': 'application/json',
       'Accept-Charset': 'utf-8',
     },
  json: true,
  body:requestData
  }; 
 
  request(options, function(err, result) {   //The function will return error/result; if you type res.send it will send that to freshsales
    
      if(err){
          console.log("error");
          res.send("ERROR");
          return;
      }
  else{
      console.log("DONE");
      console.log(result); //It has logged all the data that came as respopnse when the operation was successful
      res.send(result);

  } 
  });

  */
//}

exports.PassLog = (req,res) =>{
    /*var requestData = {

    "phone_call": 
    {   
    "call_direction":  req.body.call_direction, 
    "targetable_type": req.body.targetable_type, 
    "targetable": 
    { 
        "id":  req.body.id, 
        "first_name": req.body.first_name, 
        "last_name":  req.body.last_name, 
        "work_number": req.body.work_number, 
        "mobile_number": req.body.mobile_number
    },

    "note":{ 
        
        "description": req.body.description
            }
    }  
};*/

        const options = {
        url: 'https://doc-mailnet.freshsales.io/api/phone_calls',    /*/ leads/req.body.id*/
        method: "POST",
       //failed-1 token:"r1OtnQ4W5Enb-x2NgV5OrA",
      
        headers: {
            "Authorization": "Token token=fKtIJNSVoMhh_vm7N4Y1Cg",
            "Content-Type": "application/json"   
           },
        json: true,
        body:req.body
        }; 

        request(options, function(err, result) { 
          
            if(err){
                console.log("ERROR")
                console.log(err);
                res.send("ERROR");
                return;
            }
        else{
           console.log(result.body);
            res.send("DONE");  
        } 
        });

};

