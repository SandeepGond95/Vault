const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const port = 3000;
var mysql = require('mysql');

app.use(bodyParser.urlencoded({extended :true}))
app.use(express.static(__dirname));

//line so that server expects data in json format only
app.use(bodyParser.json())

var connection = mysql.createConnection({
    host: '192.168.0.115',
    user: 'sandeep',
    password: 'Slashrtc@123',
    database: 'Lead'
}); 
connection.connect( function (err,val) {
    if(val){
        console.log("connection successful");
    }
    else{
        console.log(err);
    }
});


//get from table
app.get('/',function(req,res) {
    connection.query("select * from info", function(error,row,fields){
        if(error){
            console.log("error in query");
        }
        else{
            console.log("query successful");
            res.send(row);
        }
    });
      
});

//post to db
/*
app.post('/', function(req,res) {
   
    let firstName = req.body.firstName;
    let phoneNo = req.body.phoneNo;

    connection.query("insert into info values('firstName','phoneNo')", (err, rows, fields) => {
        if(err){
            console.log("error in query");
        }
        else{
            console.log("query successful");
            res.send(rows);
        }

    });
});
*/


//Insert an employee
app.post('/', (req, res) => {
    let firstName = req.body.firstName;
    let phoneNo = req.body.phoneNo;
    var sql = `INSERT INTO info(firstName,phoneNo) VALUES ("${firstName}","${phoneNo}")`;
    connection.query(sql, (err, rows, fields) => {
        if (err){
            res.send(err);

        }
        else{

            connection.query("select * from info", function(error,row,fields){
                if(error){
                    console.log("error in query");
                }
                else{
                    console.log("query successful");
                    res.json({status:'successful', row});
                    console.log("values pushed successfully");
                }
            });
           
        }
    });
});


//create a table for an employee
app.post('/creator', (req, res) => {

    var sql = `CREATE TABLE customers (name VARCHAR(30), address VARCHAR(35))`;
    connection.query(sql, (err, rows, fields) => {
        if (err){
            res.send(err);

        }
        else{
            res.send("table created");
           
        }
    });
});

//updating an entry
app.put('/', (req,res) =>{
    let phoneNo = req.body.phoneNo;

connection.query(`update info set firstName ="pappu" where phoneNo = ${phoneNo}` ,(err,rows,fields) =>{

    if(err){
        res.send(err);
    }
    else{
        res.send("updated successfully");
    }
});
});


//Delete an employees
app.delete('/', (req, res) => {
    let firstName = req.body.firstName;
    connection.query(`DELETE FROM info WHERE firstName = "${firstName}"`,(err, rows, fields) => {
        if (err){
            res.send(err);

        }
        else{
            res.send("deleted successfully");
           
        }
    });
});

app.listen(port , () =>{
    console.log("server listening on port: "+port);
});