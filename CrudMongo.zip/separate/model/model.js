const mongoose = require('mongoose');

const lead_model = mongoose.Schema({
  lead_id: Number,
  lead_first_name: String,
  lead_last_name: String,
  lead_email: String,
  lead_work_number: String,
  lead_mobile_number: String,
  lead_company_name: String,
});

module.exports = mongoose.model('lead_details',lead_model);