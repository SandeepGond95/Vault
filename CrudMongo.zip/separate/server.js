const express = require('express')
const port = 5000;
const bodyParser = require('body-parser');
const router = require('./Router/route');
const mongoose = require('mongoose');
const app = express();

app.use(bodyParser.urlencoded({extended :true}))
app.use(express.static(__dirname));
app.use(bodyParser.json());

app.use("/",router);

mongoose.connect('mongodb://localhost:27017/Lead',(err,val) =>{
    if(val){
        console.log("connected succesfully");
    }
    else{
        console.log(err);
    }
});

app.listen(port, () =>{
    console.log("Server is listening on port:" + port);
});
