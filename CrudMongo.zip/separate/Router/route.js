const express = require('express');
const router = express.Router();
const logic = require('../controller/controller');

//fetches data when lead is created and passes to the dialer
router.post("/FetchLead",logic.Receivelead);

//pushes data as call log into the specified lead
router.post("/AddLog",logic.PassLog);

//pushes updated data
//router.put("/UpdateLead",logic.updateLead);

module.exports = router;