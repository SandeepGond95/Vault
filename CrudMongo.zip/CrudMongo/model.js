const mongoose = require('mongoose');

const Test = mongoose.Schema({
    Stage: String,
    Phase:  String,
    phoneNo: Number
});


module.exports = mongoose.model('aajs',Test);

