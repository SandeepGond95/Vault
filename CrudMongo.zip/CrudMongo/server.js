const express = require('express')
const app = express();
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const request = require('request');
const port = 5000;
const mymodel = require('./model');
const modale = require('./modal');




//line to extract body from request
app.use(bodyParser.urlencoded({extended :true}))
app.use(express.static(__dirname));

//line so that server expects data in json format only
app.use(bodyParser.json())

//setting up the server
mongoose.connect('mongodb://localhost:27017/Tag',(err,val) =>{
    if(val){
        console.log("connected succesfully");
    }
    else{
        console.log(err);
    }
});


//retrieve all/ selective
app.get('/geting', (req,res) =>{
    mymodel.find().then(val => {
        if(val)
        {
            console.log("found");
            console.log(val);
          
                res.send(val);

        }
        else{
            console.log("not found"); 
        }
        
    });
});

//create an entry
app.post('/', (req,res) => {
    console.log("Query : ",req.query);
    console.log("Params : ",req.params);
    console.log("Body : ",req.body);


    var requestData = {
        "json":{
            "customerNumber" : req.body.customerNumber,
            "customerName": req.body.customerName,
            "customerEmail":req.body.customerEmail,
            "processId": "5",
            "processName":"Auto",
            "processType": "Auto",
            "campaignId" : "1",
            "campaignName": "Test",
            "leadsetId": "5",
            "leadsetName": "iidetest",
            "leadScore" : 1000 
        },
    }

 const options = {
    url: 'https://iide.slashrtc.com/slashRtc/webApis/setLeadDetailInProcess',
    method: "POST",
    rejectUnauthorized: false,
   headers: {
        'content-type': 'application/json',
        'Accept': 'application/json',
         'Accept-Charset': 'utf-8',
       },
    json: true,
    body:requestData
 };


    request(options, function(err, res, body) {
        console.log("posted data");
        console.log(res.body);
        console.log(res);
      //  res.send("done");
    });
});



/*
//updating entries
app.put('/', (req,res) =>{
    mymodel.findOneAndUpdate({"phoneNo":req.body.phoneNo}, {$set:{"Stage":req.body.Stage,"Phase":req.body.Phase}}).then(val => {
        if(val)
        {
            console.log(" Entry found");
            console.log(val);
          
                res.send(val)

        }
        else{
            console.log("not found"); 
        }
        
    });

});


//deleting an entry
app.delete('/', (req,res) =>{
    mymodel.findOneAndDelete({"phoneNo":req.body.phoneNo}).then(val => {
        if(val)
        {
            console.log(val);
            res.send("Entry found and deleted")

        }
        else{
            res.send("Entry not found")
        }
        
    });
});






/*
app.get('/', (req,res) =>{
    mymodel.find({Stage:req.body.Stage},{Phase:1}).then(val => {
        if(val)
        {
            console.log("found");
            res.send(val);
            
        }
        else{
            console.log("not found");
             
        }
        
    })
})

app.post('/', (req,res) => {
    const obj = new mymodel({
        Stage:req.body.Stage,
        Phase:req.body.Phase,
        phoneNo: req.body.phoneNo

    });
    obj.save().then((err,val)=>{
        if(val){
            res.send(val);
        }else {
            res.send(err);
        }
    });

});
*/


app.listen(port, () =>{
    console.log("server is listening on :" +port);
});


