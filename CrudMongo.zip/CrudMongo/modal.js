const mongoose = require('mongoose');

const TestOne = mongoose.Schema({
    Stage: String,
    phoneNo: Number
});

module.exports = mongoose.model('kals',TestOne);