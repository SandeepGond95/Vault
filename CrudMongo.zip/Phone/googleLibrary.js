
const PNF = require('google-libphonenumber').PhoneNumberFormat;
 
const phoneUtil = require('google-libphonenumber').PhoneNumberUtil.getInstance();
 
var num  = "+19022979478";

const number = phoneUtil.parseAndKeepRawInput(num, '');


var numberLength = num.length;
console.log(numberLength);

    try {
        // phone must begin with '+'
        const numberProto = phoneUtil.parse(num, "");
        const countryCode = numberProto.getCountryCode();
        console.log(countryCode);
    } 

    catch (NumberParseException) {
        console.log("NumberParseException was thrown: " + e.toString());
    }

// if(numberLength <= 10){
    
//     if(phoneUtil.isValidNumber(number)){
//         console.log(num,"Is Valid");
//     }
//     else{
//         console.log(num,"Is Not Valid");   
//     }
// }
// else{

    console.log("", phoneUtil.isValidNumber(number));
// }























//Code using libphonenumber-js

// const libphonenumber = require('libphonenumber-js').parsePhoneNumberFromString;

// var num  = "02227709683";


// const phoneNumber = libphonenumber(num);
//  console.log(phoneNumber);

//     if(phoneNumber.isValid()){
//         console.log(num,"Is Valid number");
//     }
    
//     else{
//         console.log(num, "Is not a Valid number");
//     }





   
