// logger functionality
  function showLog (log, output1, output2, criticalVar) {

    // showAll logs variable
      var showAllLogs = 0,  // make it 1 to throw all Logs
          lineByLine  = 0;  // make it 1 to show logs line by line

    // decide on criticalVar for logging
      if ( criticalVar === 1 || showAllLogs === 1 ) {

        if ( lineByLine === 0 ) {

          var consoler  = JSON.stringify({
            "LOG"       : log,
            "OUTPUT_1"  : output1,
            "OUTPUT_2"  : output2
          });
  
          console.log(consoler);
        } else {

          var consoler  = JSON.stringify({
            "LOG"       : log,
            "OUTPUT_1"  : output1,
            "OUTPUT_2"  : output2
          }, null, 2);
  
          console.log(consoler);
        }
      }
  }

// slash character check
  function slashCheck (phoneNumber) {

    // invoking the check slash function

      var checkSlash  = new RegExp("/");

    // returning the tested value

      return checkSlash.test(phoneNumber);
  }

// slash "/" character(s) indexes function
  function indexesOfSlash (string, regex) {

    var match,
        indexes = {},
        regex   = new RegExp(regex);

    while (match = regex.exec(string)) {
      if (!indexes[match[0]]) indexes[match[0]] = [];
      indexes[match[0]].push(match.index);
    }

    return indexes;
  }

// variablizing
  // var phoneNumberString  = "1234/";
  var phoneNumberString = "91982036225/,"
                        + "911234567890,"
                        + "919876543210/,"
                        + "9198765432100,"
                        + "919876543/210/1/2/3456/400,"
                        + "919876543210/1/2/3456//400,"
                        + "919876543210/1/2/3456/799/";

  // consoler
    showLog(
      "ACTUAL_PHONE_NUMBER_STRING",
      phoneNumberString,
      phoneNumberString.length,
      1
    );

// Sanitizing the string except splitters & slash "/"
  var replaceExceptNumbers  = phoneNumberString.replace(/[^0-9|,|:|;|\r\n|\t|\n|/|\|]/g, '');
  showLog(
    "REPLACED_WITH_EXCEPT_SPLITTERS_SLASH",
    replaceExceptNumbers,
    replaceExceptNumbers.length,
    0
  );

// splitting the phone numbers using splitter defs
  var initPhonesArray = replaceExceptNumbers.split(/[,:;\r\n\t\n|]+/);
  showLog("PHONE_NUMBER_ARRAY", initPhonesArray, 0, 0);

// Phone number recognition starts here
  for ( var i= 0; i < initPhonesArray.length; i++ ) {

    // variablizing

      var phoneNumber = initPhonesArray[i];

    // phone number length
      var phoneNumberLength = phoneNumber.length;
      showLog("PHONE_NUMBER_LENGTH", phoneNumber, phoneNumberLength, 0);

    // cases for phone number length
      if ( phoneNumberLength === 10 ) {

        // check for slash character

          var checkSlash  = slashCheck(phoneNumber);

        // decide on the output
          if ( checkSlash === true ) {

            showLog("INVALID_PHONE_NUMBER", phoneNumber, phoneNumberLength, 1);
          } else {

            // check for leading zero

              var checkForLeadingZero = phoneNumber.slice(0,1);

            // decide on the above output
              if ( checkForLeadingZero  !== "0" ) {

                showLog("VALID_PHONE_NUMBER", phoneNumber, phoneNumberLength, 1);
              } else {

                showLog("INVALID_PHONE_NUMBER_LEADING_ZERO_10_DIGIT", phoneNumber, phoneNumberLength, 1);
              }
          }
      } else if ( phoneNumberLength === 11 ) {

        // Two Cases i.) leading 0's ii.) trailing "/"
        // Handling the first most often case, leading 0's

          var checkForLeadingZero = phoneNumber.slice(0, 1);

        // decide on the value fetched above
          if ( checkForLeadingZero  === "0" ) {

            // mod phoneNumber

              var modPhoneNumber  = phoneNumber.slice(1, phoneNumberLength);

            // consoler
              showLog(
                "VALID_PHONE_NUMBER_11_DIGIT_LEADING_ZERO",
                modPhoneNumber,
                modPhoneNumber.length,
                1
              );
          } else {

            // handling the second case to check for trailing "/"
            // check for slash character

              var checkSlash  = slashCheck(phoneNumber);

            // decide on the output
              if ( checkSlash === true ) {

                // check where is the slash

                  var slashPoint  = phoneNumber.indexOf("/");

                // decide whether slash is at the end
                  if ( slashPoint === (phoneNumberLength - 1) ) {

                    // mod phonenumber is

                      var modPhoneNumber  = phoneNumber.slice(0, (phoneNumberLength - 1));

                    // consoler
                      showLog(
                        "VALID_PHONE_NUMBER_11_DIGIT_END_SLASH",
                        modPhoneNumber,
                        modPhoneNumber.length,
                        1
                      )
                  } else {

                    showLog("INVALID_PHONE_NUMBER_11_DIGIT", phoneNumber, phoneNumberLength, 1);
                  }
              } else {

                showLog("INVALID_PHONE_NUMBER_11_DIGIT", phoneNumber, phoneNumberLength, 1);
              }
          }
      } else if ( phoneNumberLength === 12 ) {

        // Cases to be handled
          // i.) Not Starting with 91
          // ii.) Starting with 91 then 10-digits
          // iii.) Starting with 91 then 10-digits but slash included

        // handling the first case

          var checkStart91  = phoneNumber.slice(0,2);

        // decide on checkStart91
          if ( checkStart91 === "91" ) {

            // variablizing

              var modPhoneNumber  = phoneNumber.slice(2, phoneNumberLength);

            // Handling the ii.) & iii.) case now
            // check for slash in the modPhoneNumber

              var checkSlash  = slashCheck(modPhoneNumber);

            // decide on the output
              if ( checkSlash === true ) {

                // consoler
                  showLog(
                    "INVALID_PHONE_NUMBER_12_DIGIT_WITH_SLASH",
                    modPhoneNumber,
                    modPhoneNumber.length,
                    1
                  );
              } else {

                // consoler
                  showLog(
                    "VALID_PHONE_NUMBER_12_DIGIT",
                    modPhoneNumber,
                    modPhoneNumber.length,
                    1
                  );
              }
          } else {

            // consoler
              showLog(
                "INVALID_PHONE_NUMBER_NOT_91",
                phoneNumber,
                phoneNumberLength,
                1
              );
          }
      } else if ( phoneNumberLength >   12 ) {

        // Cases to be handled
          //   i.) Starting with 91, 11 Digits, Last is "/"
          //  ii.) Starting with 91, 11 Digits, Last is not "/"
          // iii.) Starting with 91, > 11 Digits, No Slash
          //  iv.) Starting with 91, > 11 Digits, with Slashes

        // Check whether it starts with 91

          var checkStart91  = phoneNumber.slice(0,2);

        // decide on 91 start
          if ( checkStart91 === "91" ) {

            // fetch the number after 91 & check for slash character(s)
              var modPhoneNumber        = phoneNumber.slice(2, phoneNumberLength),
                  modPhoneNumberLength  = modPhoneNumber.length,
                  checkSlash            = slashCheck(modPhoneNumber);

            // decide on checkSlash output
              if ( checkSlash === true ) {

                // check where is the slash

                  var slashPoint  = modPhoneNumber.indexOf("/");

                // check for 11-Digit after 91 ending with Slash Character
                  if ( modPhoneNumberLength === 11 ) {

                    // decide whether slash is at the end
                      if ( slashPoint === (modPhoneNumberLength - 1) ) {

                        // mod phonenumber is

                          var modPhoneNumberSlash = modPhoneNumber.slice(0, (modPhoneNumberLength - 1));

                        // consoler
                          showLog(
                            "VALID_PHONE_NUMBER_G-12_DIGIT_11_DIGIT_END_SLASH",
                            modPhoneNumberSlash,
                            modPhoneNumberSlash.length,
                            1
                          )
                      } else {

                        // consoler
                          showLog(
                            "INVALID_PHONE_NUMBER_G-12_DIGIT_11_DIGIT_NO-END_SLASH",
                            modPhoneNumber,
                            modPhoneNumberLength,
                            1
                          );
                      }
                  } else if ( modPhoneNumberLength > 11 ) {

                    // fetch the slash indexes
                      var slashIndexes  = indexesOfSlash(modPhoneNumber, /\//g),
                          slashArray    = slashIndexes["/"];

                    // check the first index of slashArray to be === 10 or else reject everything
                      if ( slashArray[0] === 10 ) {

                        // valid phone number array

                          var phoneNumberArray  = [];

                        // iterate over the slashArray to produce multiple phone numbers
                          for ( j = 0,k = 1; j < slashArray.length; j++ ) {

                            // increment "k" variable to check for last iteration

                              k++

                            // based on "k" value take the decision
                              if ( k > slashArray.length ) {

                                // variablizing
                                  var modLastDigits       = modPhoneNumber.slice(
                                                              (slashArray[j] + 1),
                                                              modPhoneNumberLength
                                                            ),
                                      modLastDigitsLength = modLastDigits.length;

                                // check on modLastDigitsLength
                                  if ( modLastDigitsLength > 0 ) {

                                    // replace the last digit with current digit(s) fetched
                                      var newPhoneNumber  = modPhoneNumber.slice(
                                                              0,
                                                              (10 - modLastDigitsLength)
                                                            ) + modLastDigits;
                                          phoneNumberArray.push(newPhoneNumber);

                                    // consoler
                                      showLog(
                                        "VALID_MOD_LAST_DIGITS",
                                        modLastDigits,
                                        newPhoneNumber,
                                        0
                                      );
                                  } else {

                                    // consoler
                                      showLog(
                                        "INVALID_MOD_LAST_DIGITS",
                                        modLastDigits,
                                        modLastDigitsLength,
                                        0
                                      );
                                  }
                              } else {

                                // variablizing
                                  var modMidDigits        = modPhoneNumber.slice(
                                                              (slashArray[j] + 1),
                                                              slashArray[j+1]
                                                            ),
                                      modMidDigitsLength  = modMidDigits.length;

                                // check on modMidDigitsLength
                                  if ( modMidDigitsLength > 0 ) {

                                    // replace the last digit with current digit(s) fetched
                                      var newPhoneNumber  = modPhoneNumber.slice(
                                                              0,
                                                              (10 - modMidDigitsLength)
                                                            ) + modMidDigits;
                                          phoneNumberArray.push(newPhoneNumber);

                                    // consoler
                                      showLog(
                                        "VALID_MOD_MID_DIGITS",
                                        modMidDigits,
                                        modMidDigitsLength,
                                        0
                                      );
                                  } else {

                                    // consoler
                                      showLog(
                                        "INVALID_MOD_MID_DIGITS",
                                        modMidDigits,
                                        modMidDigitsLength,
                                        0
                                      );
                                  }
                              }
                          }

                        // check on phoneNumberArray and consoler
                          if ( phoneNumberArray.length > 0 ) {

                            // consoler
                              showLog(
                                "VALID_G-12_DIGITS_MOD_DIGITS_ARRAY",
                                phoneNumberArray,
                                phoneNumberArray.length,
                                1
                              );
                          }
                      } else {

                        // consoler
                          showLog(
                            "INVALID_NUMBER_FORMAT_G-12_DIGIT_WITH_SLASH_BEFORE_10th-DIGIT",
                            modPhoneNumber,
                            modPhoneNumberLength,
                            1
                          );
                      }
                  }
              } else {

                // consoler
                  showLog(
                    "INVALID_PHONE_NUMBER_G-12_DIGIT_WITH_91_WITHOUT_SLASH",
                    modPhoneNumber,
                    modPhoneNumberLength,
                    1
                  );
              }
          } else {

            // consoler
              showLog(
                "INVALID_PHONE_NUMBER_12_DIGIT_NOT_91",
                phoneNumber,
                phoneNumberLength,
                1
              );
          }
      } else {

        showLog("INVALID_PHONE_NUMBER_LENGTH", phoneNumber, phoneNumberLength, 1);
        return;
      }
  }